package com.example.itemsdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItemsdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
